# NSE AI Breakout Bot — GitHub Actions Setup

No server, no card, no signup beyond GitHub itself.

## 1. Make the repo PUBLIC

This is the fix for the "data/minutes exhausted" problem you hit before.
GitHub Actions gives **unlimited free minutes on public repositories**,
but only 2,000 minutes/month on private ones — and this bot's schedule
(a scan + a check every 5 minutes for 6+ hours a day) will blow past that
on a private repo within weeks.

Your `BOT_TOKEN` and `CHAT_ID` stay safe either way — they're stored as
encrypted GitHub Secrets, never written into the code.

If your repo is currently private:
Repo → **Settings** → scroll to **Danger Zone** → **Change visibility** → **Make public**.

## 2. Add your files to the repo

Commit these to the root of your repo, keeping the folder structure:

```
nse_ai_breakout_actions.py
requirements.txt
data/.gitkeep
.github/workflows/premarket_scan.yml
.github/workflows/universe_rescan.yml
.github/workflows/intraday_recheck.yml
```

## 3. Add your secrets

Repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**.

Add two secrets:
- `BOT_TOKEN` — your Telegram bot token
- `CHAT_ID` — your Telegram chat ID

## 4. Enable Actions permissions

Repo → **Settings** → **Actions** → **General** → under "Workflow permissions",
select **Read and write permissions**, then save. (The workflows commit
data back to the repo, so they need write access.)

## 5. Test it manually first

Repo → **Actions** tab → click **Pre-Market Scan** → **Run workflow** →
**Run workflow** button. Watch it run, and check your Telegram for the
morning report. Do the same for the other two workflows to confirm they
work before relying on the schedules.

## 6. What runs when (IST)

| Workflow | Schedule | What it does |
|---|---|---|
| Pre-Market Scan | 8:45 AM, Mon–Fri | Full NSE scan, builds watchlist, sends morning report |
| Universe Rescan | Every 30 min, market hours | Finds NEW stocks that now qualify, adds to watchlist |
| Intraday Recheck | Every 5 min, market hours | Checks watchlist for volume-spike buy signals |

Note: GitHub's scheduled cron is "best effort" — it can run a few minutes
late during busy periods. Since the underlying data (yfinance/Yahoo) is
itself ~15+ min delayed, this doesn't meaningfully change what the bot can
detect.

## 7. Adjusting behavior

All filter thresholds are environment variables with sensible defaults
(see the top of `nse_ai_breakout_actions.py`). To change one, add it as
an environment variable in the relevant workflow's `env:` block, e.g.:

```yaml
      - name: Run morning scan
        env:
          BOT_TOKEN: ${{ secrets.BOT_TOKEN }}
          CHAT_ID: ${{ secrets.CHAT_ID }}
          MIN_PRICE: "150"
        run: python nse_ai_breakout_actions.py scan
```
